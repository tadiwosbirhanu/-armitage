java -classpath bin:lib/\*:. armitage.ArmitageMain $*
