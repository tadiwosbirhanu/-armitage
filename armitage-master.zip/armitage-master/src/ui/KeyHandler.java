package ui;

public interface KeyHandler {
	public void key_pressed(String description);
}
