package msf;

public interface RpcCallback {
	public void result(Object result);
}
